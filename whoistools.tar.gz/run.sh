#!/bin/bash

domains=`cat domain.txt`

source ./common_profile.cnf

limit_parallel_executor 5 0 "$domains" ./whois.sh
