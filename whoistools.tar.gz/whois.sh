#!/bin/bash

domain=$1

result=`whois $domain | grep "No match for" | wc -l`

if [ $result = 1 ];
then
	echo "$domain NOT REGISTERED" >> result.txt
fi
